public class SnakeFellException extends RuntimeException {
    public SnakeFellException(String message) {
        super(message);
    }
}
