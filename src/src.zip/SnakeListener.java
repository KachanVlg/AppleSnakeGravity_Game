public interface SnakeListener {

    void portalIsEntered();
    void fell();
    void movedOn();
}
