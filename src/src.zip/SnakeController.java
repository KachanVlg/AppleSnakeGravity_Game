public interface SnakeController {

    void moveOn(Direction dir);
    void addListener(SnakeListener listener);
}
